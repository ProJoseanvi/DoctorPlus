package com.example.doctorplus.UserInterface;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.doctorplus.R;

public class SearchCreate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_create);
    }
}