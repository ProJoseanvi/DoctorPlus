package com.example.doctorplus.Common;

//Aqui añadiremos constantes accesibles desde todas las partes de la App
 public class Constantes {
     public static final String API_DOCTORPLUS_BASE_URL = "http://192.168.1.72:8080/demo/";

     public static final String USER_ROLE = "user_role";
    public static final String USER_ID = "user_id";
    public static final String USER_NAME = "user_name";

    public static final String ROLE_MEDIC = "1";

    public static final String ROLE_OTHERS = "2";
}
