package com.example.doctorplus.UserInterface;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.doctorplus.R;

public class MedicUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.medic_user);
    }

    public void onClickBuscarReceta(View view) {
        Intent intent = new Intent(this, SearchCreate.class);
        startActivity(intent);
    }

}

