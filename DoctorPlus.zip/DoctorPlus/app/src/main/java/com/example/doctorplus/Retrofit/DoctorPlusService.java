package com.example.doctorplus.Retrofit;

//Registraremos aqui tooos los servicios de la API

import com.example.doctorplus.Retrofit.Request.RequestLogin;
import com.example.doctorplus.Retrofit.Response.ResponseAuth;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface DoctorPlusService {

    //Aqui añadimos nuestro primer servicio el POST para hacer Login
    @POST("login")
    Call<ResponseAuth> doLogin(@Body RequestLogin requestLogin);

}
